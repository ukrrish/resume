# -*- coding: utf-8 -*-
"""
Created on Wed May 31 12:11:38 2017

@author: udaya105712
"""

#Preprocess BiDAF
from __future__ import unicode_literals

import sys
import random
import codecs
import datetime
import logging
import time
import shutil
import unicodedata
import nltk
import os
import re
import csv
import codecs
import numpy as np
import pandas as pd
import keras
import random
import sys
import re
import six.moves.cPickle


from gensim.models import KeyedVectors
from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences
from keras.layers import Input, LSTM, Embedding, Dropout
from keras.models import Model
from keras.layers.normalization import BatchNormalization
from keras.layers import Conv1D, MaxPooling1D, Embedding
from keras.callbacks import EarlyStopping, ModelCheckpoint
from keras.utils import to_categorical
from keras.preprocessing import sequence
from keras.models import Sequential
from keras.layers import Dense, Embedding
from keras.layers.core import Flatten,Dense, Activation
from keras.layers import Conv1D, GlobalMaxPooling1D, MaxPooling1D
from sklearn.model_selection import train_test_split
from gensim.models import KeyedVectors
from keras.layers import Input,concatenate,Highway
from keras.layers.wrappers import TimeDistributed,Bidirectional

import os
from keras.layers import Dense,Input,LSTM,Bidirectional,Activation,Conv1D,GRU
from keras.callbacks import Callback
from keras.layers import Dropout,Embedding,GlobalMaxPooling1D, MaxPooling1D, Add, Flatten
from keras.preprocessing import text, sequence
from keras.layers import GlobalAveragePooling1D, GlobalMaxPooling1D, concatenate, SpatialDropout1D
from keras import initializers, regularizers, constraints, optimizers, layers, callbacks
from keras.callbacks import EarlyStopping,ModelCheckpoint
from keras.layers import Input,concatenate,Highway
from keras.layers.wrappers import TimeDistributed,Bidirectional
from keras.models import Model
from keras.optimizers import Adam
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.metrics import roc_auc_score

from sklearn.svm import SVC
from sklearn.feature_extraction.text import TfidfVectorizer
from random import randint
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import precision_recall_fscore_support
from sklearn.cross_validation import train_test_split
from sklearn import cross_validation
from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report
from sklearn.cross_validation import KFold





reload(sys)
sys.setdefaultencoding('utf-8')
random.seed(111)

#def main():
def cust_loss(y_true,y_pred):
	loss=-K.log(K.sum(y_true* y_pred,axis=-1))
	return(loss)



def strip_accents(s):
	return ''.join(c for c in unicodedata.normalize('NFD', s)
				  if unicodedata.category(c) != 'Mn')

def clean_str(string):
	"""
	Tokenization/string cleaning for dataset
  
	"""
	string = re.sub(r"\\", "", string)
	string = re.sub(r"\'", "", string)
	string = re.sub(r"\"", "", string)
	return string.strip()

def remove_non_ascii(text):
	text=re.sub(r'\n'," ",text)
	text=re.sub(r'\r'," ",text)
	text=re.sub(r'\\n'," ",text)
	text=re.sub(r'\\r'," ",text)
	return re.sub(r'[^\x00-\x7F]+',' ', text)

def text_cleaner(text):
	#text = text.replace(".", "")
	text = text.replace("[", " ")
	#text = text.replace(",", " ")
	text = text.replace("]", " ")
	text = text.replace("(", " ")
	text = text.replace(")", " ")
	text = text.replace("\"", "")
	#text = text.replace("-", "")
	text = text.replace("=", "")
	#text = text.replace(":", "")
	#text = text.replace("*", "")
	text = text.replace("_", " ")
	text = text.replace(";", " ")
	#text = text.replace("$", " ")
	text = text.replace("?", " ")
	text = text.replace("\’", " ")
	#text = text.replace("&nbsp", " ")
	#text = text.replace("&#", " ")		
	text = remove_non_ascii(text)
	rules = [
		{r'>\s+': u'>'},  # remove spaces after a tag opens or closes
		{r'\s+': u' '},  # replace consecutive spaces
		{r'\s*<br\s*/?>\s*': u'\n'},  # newline after a <br>
		{r'</(div)\s*>\s*': u'\n'},  # newline after </p> and </div> and <h1/>...
		{r'</(p|h\d)\s*>\s*': u'\n\n'},  # newline after </p> and </div> and <h1/>...
		{r'<head>.*<\s*(/head|body)[^>]*>': u''},  # remove <head> to </head>
		{r'<a\s+href="([^"]+)"[^>]*>.*</a>': r'\1'},  # show links instead of texts
		{r'[ \t]*<[^<]*?/?>': u''},  # remove remaining tags
		{r'^\s+': u''},  # remove spaces at the beginning
		#{ur"[\u4e00-\u9fff]+": u""}
		]
	for rule in rules:
		for (k, v) in rule.items():
			regex = re.compile(k)
			text = regex.sub(v, text)
		text = text.rstrip()
		text = text.strip()
		text = text.lower()
		text = strip_accents(text)
	return text

class RocAucEvaluation(Callback):
	def __init__(self, validation_data=(), interval=1):
		super(Callback, self).__init__()
		self.interval = interval
		self.X_val, self.y_val = validation_data
	def on_epoch_end(self, epoch, logs={}):
		if epoch % self.interval == 0:
			y_pred = self.model.predict(self.X_val, verbose=0)
			score = roc_auc_score(self.y_val, y_pred)
			print("\n ROC-AUC - epoch: {:d} - score: {:.6f}".format(epoch+1, score))


def get_model():
	sequence_input = Input(shape=(max_seq_len, ))
	x = Embedding(num_words, EMBEDDING_DIM, weights=[embedding_matrix],trainable = False)(sequence_input)
	x = SpatialDropout1D(0.2)(x)
	x = Bidirectional(LSTM(128, return_sequences=True,dropout=0.1,recurrent_dropout=0.1))(x)
	x = TimeDistributed(Highway(activation="relu"))(x)
	x = TimeDistributed(Highway(activation="relu"))(x)
	x = Conv1D(128, kernel_size = 3, padding = "valid", kernel_initializer = "glorot_uniform")(x)
	x = MaxPooling1D(pool_size=5)(x)
	x = Conv1D(64, kernel_size = 3, padding = "valid", kernel_initializer = "glorot_uniform")(x)
	x = MaxPooling1D(pool_size=3)(x)
	x = Conv1D(32, kernel_size = 3, padding = "valid", kernel_initializer = "glorot_uniform")(x)
	avg_pool = GlobalAveragePooling1D()(x)
	max_pool = GlobalMaxPooling1D()(x)
	x = concatenate([avg_pool, max_pool]) 
	#x = Dense(128, activation='relu')(x)
	#x = Dropout(0.1)(x)
	preds = Dense(6, activation="sigmoid")(x)
	model = Model(sequence_input, preds)
	model.compile(loss='binary_crossentropy',optimizer=Adam(lr=1e-3),metrics=['accuracy'])
	return(model)


def main():
	MAX_NB_WORDS = 200000
	EMBEDDING_DIM = 300
	max_seq_len = 100

	kernel_size=2
	CNN_filters=128
	pool_size=2
	nbatch_size=128
	num_words=340810
	embedding_matrix=np.load("/home/CORP/udaya105712/Documents/ProductDevelopment/AMEX_GBT/embedding_matrix_"+str(num_words)+"_"+str(EMBEDDING_DIM)+".npy")
	X = np.load("/home/CORP/udaya105712/Documents/ProductDevelopment/AMEX_GBT/X.npy")
	Y= np.load("/home/CORP/udaya105712/Documents/ProductDevelopment/AMEX_GBT/Y.npy")
	test_X = np.load("/home/CORP/udaya105712/Documents/ProductDevelopment/AMEX_GBT/test_X.npy")
	df1=pd.read_csv("/home/CORP/udaya105712/Documents/ProductDevelopment/AMEX_GBT/on_preds.csv")

	def get_model():
		sequence_input = Input(shape=(max_seq_len, ))
		x = Embedding(num_words, EMBEDDING_DIM, weights=[embedding_matrix],trainable = False)(sequence_input)
		x = SpatialDropout1D(0.2)(x)
		x = Bidirectional(GRU(128, return_sequences=True,dropout=0.1,recurrent_dropout=0.1))(x)
		x = Conv1D(64, kernel_size = 3, padding = "valid", kernel_initializer = "glorot_uniform")(x)
		x = Conv1D(64, kernel_size = 3, padding = "valid", kernel_initializer = "glorot_uniform")(x)
		#avg_pool = GlobalAveragePooling1D()(x)
		max_pool = GlobalMaxPooling1D()(x)
		#x = concatenate([avg_pool, max_pool]) 
		# x = Dense(128, activation='relu')(x)
		# x = Dropout(0.1)(x)
		preds = Dense(6, activation="sigmoid")(max_pool)
		model = Model(sequence_input, preds)
		model.compile(loss='binary_crossentropy',optimizer=Adam(lr=1e-3),metrics=['accuracy'])

		return(model)		

	#define the cross validation
	skf = KFold(X.shape[0], n_folds=4,shuffle=True) #2-fold cross validation
	#len(skf)
	fold=0
	oof_x=[]
	oof_y=[]
	for train_index, test_index in skf:
		fold=fold+1
		print("TRAIN:", train_index, "TEST:", test_index)
		X_train, X_test = X[train_index], X[test_index]
		y_train, y_test = Y[train_index], Y[test_index]
		model=get_model()
		MODEL_PATH="/home/CORP/udaya105712/Documents/ProductDevelopment/AMEX_GBT/cvpickles/"
		SUBMISSION_PATH = "/home/CORP/udaya105712/Documents/ProductDevelopment/AMEX_GBT/submissions/"
		checkpoint = ModelCheckpoint(MODEL_PATH+'model_uk_model_3_fold_'+str(fold)+'.hdf5', monitor='val_acc', verbose=1, save_best_only=True, mode='max')
		early = EarlyStopping(monitor="val_acc", mode="max", patience=5)
		ra_val = RocAucEvaluation(validation_data=(X_test, y_test), interval = 1)
		callbacks_list = [ra_val,checkpoint, early]
		batch_size = 64
		epochs = 7
		model.fit(X_train, y_train, batch_size=batch_size, epochs=epochs, validation_data=(X_test, y_test),callbacks = callbacks_list,verbose=1)
		model.load_weights(MODEL_PATH+'model_uk_model_3_fold_'+str(fold)+'.hdf5')
		print('Predicting....')
		val_pred = model.predict(X_test,batch_size=64,verbose=1)
		if fold ==1:
			oof_x = val_pred
			oof_y = y_test
		else:
			oof_x=np.vstack((oof_x, val_pred))
			oof_y=np.vstack((oof_y, y_test))
		y_pred = model.predict(test_X,batch_size=64,verbose=1)
		#prediction=model.predict(test_X,batch_size=64,verbose=1)
		sub_pred=pd.DataFrame(y_pred,columns=["toxic",  "severe_toxic", "obscene",  "threat"    ,"insult",  "identity_hate"])
		sub_id=pd.DataFrame(df1["id"],columns=["id"])
		sub_uk=pd.concat([sub_id,sub_pred],axis=1)
		sub_uk.to_csv(SUBMISSION_PATH+'submission_uk_model_3_fold_'+str(fold)+'.csv', index=False)

	OOF_PATH="/home/CORP/udaya105712/Documents/ProductDevelopment/AMEX_GBT/oof/"
	np.save(OOF_PATH+'oof_x_model_3.npy',oof_x)
	np.save(OOF_PATH+'oof_y_model_3.npy',oof_y)

if __name__ == '__main__':
	import tensorflow as tf
	os.environ['CUDA_VISIBLE_DEVICES']="-1"
	#config = tf.ConfigProto(device_count={"GPU":0})
	#config.gpu_options.allow_growth = True
	with tf.Session() as sess:
		with tf.device('/cpu:0'):
			sess.run(main())
