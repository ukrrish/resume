# -*- coding: utf-8 -*-
"""
Created on Wed May 31 12:11:38 2017

@author: udaya105712
"""

#Preprocess BiDAF
#from __future__ import unicode_literals

# -*- coding: utf-8 -*-
"""
Created on Wed May 31 12:11:38 2017

@author: udaya105712
"""

# #Preprocess BiDAF
import argparse
import json
import os
import nltk
from collections import Counter
from tqdm import tqdm
import sys
import re

import keras
import tensorflow as tf
from keras.optimizers import Adadelta
from keras.models import Sequential
from keras.layers import Input,concatenate,Highway
from keras.layers.wrappers import TimeDistributed,Bidirectional
from keras.layers.core import Dense, Dropout, Activation, Flatten, Reshape
from keras.layers.embeddings import Embedding
from keras.layers.recurrent import LSTM, GRU
from keras.layers.convolutional import Convolution1D, MaxPooling1D, Convolution2D, MaxPooling2D
from keras.preprocessing.sequence import pad_sequences
from keras.callbacks import ModelCheckpoint, LearningRateScheduler,Callback,ProgbarLogger
import pandas as pd
import numpy as np
import re
import os
import random
from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences
from keras.utils import to_categorical
from keras.models import Model
import keras.backend as K
from keras.layers import Dense, Activation, Multiply, Add, Lambda
import keras.initializers
from keras import backend as K
from keras.engine.topology import Layer
import numpy as np
from keras import activations, initializers
from typing import List
from keras import backend as K
from keras import backend as K
from keras.engine.topology import Layer
import numpy as np
from typing import List
from keras import backend as K
import AttentionLayer as at
import time
from keras.layers import Highway
import six.moves.cPickle

import pandas as pd
import numpy as np
import os
import re
import random
import nltk
import operator


#import sys
import random
import codecs
import datetime
import logging
import time
import shutil
import unicodedata
import nltk
import os
import re
import csv
import codecs
import numpy as np
import pandas as pd
import keras
import random
#import sys
import re
import six.moves.cPickle


from gensim.models import KeyedVectors
from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences
from keras.layers import Input, LSTM, Embedding, Dropout
from keras.models import Model
from keras.layers.normalization import BatchNormalization
from keras.layers import Conv1D, MaxPooling1D, Embedding
from keras.callbacks import EarlyStopping, ModelCheckpoint
from keras.utils import to_categorical
from keras.preprocessing import sequence
from keras.models import Sequential
from keras.layers import Dense, Embedding
from keras.layers.core import Flatten,Dense, Activation
from keras.layers import Conv1D, GlobalMaxPooling1D, MaxPooling1D
from sklearn.model_selection import train_test_split
from gensim.models import KeyedVectors
from keras.layers import Input,concatenate,Highway
from keras.layers.wrappers import TimeDistributed,Bidirectional

from sklearn.svm import SVC
from sklearn.feature_extraction.text import TfidfVectorizer
from random import randint
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import precision_recall_fscore_support
from sklearn.cross_validation import train_test_split
from sklearn import cross_validation
from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report
from sklearn.linear_model import LogisticRegression
from sklearn import svm
from sklearn.svm import SVC
from collections import Counter
from sklearn.feature_extraction.text import CountVectorizer
#import cPickle

from gensim.models import KeyedVectors
from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences
from keras.layers import Input, LSTM, Embedding, Dropout
from keras.models import Model
from keras.layers.normalization import BatchNormalization
from keras.layers import Conv1D, MaxPooling1D, Embedding
from keras.callbacks import EarlyStopping, ModelCheckpoint
from keras.utils import to_categorical
from keras.preprocessing import sequence
from keras.models import Sequential
from keras.layers import Dense, Embedding
from keras.layers.core import Flatten,Dense, Activation
from keras.layers import Conv1D, GlobalMaxPooling1D, MaxPooling1D
from sklearn.model_selection import train_test_split
from gensim.models import KeyedVectors
from keras.layers import Input,concatenate,Highway
from keras.layers.wrappers import TimeDistributed,Bidirectional

import os
from keras.layers import Dense,Input,LSTM,Bidirectional,Activation,Conv1D,GRU
from keras.callbacks import Callback
from keras.layers import Dropout,Embedding,GlobalMaxPooling1D, MaxPooling1D, Add, Flatten
from keras.preprocessing import text, sequence
from keras.layers import GlobalAveragePooling1D, GlobalMaxPooling1D, concatenate, SpatialDropout1D
from keras import initializers, regularizers, constraints, optimizers, layers, callbacks
from keras.callbacks import EarlyStopping,ModelCheckpoint
from keras.layers import Input,concatenate,Highway
from keras.layers.wrappers import TimeDistributed,Bidirectional
from keras.models import Model
from keras.optimizers import Adam
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.metrics import roc_auc_score



#reload(sys)
#sys.setdefaultencoding('utf-8')
random.seed(111)

#def main():
def cust_loss(y_true,y_pred):
	loss=-K.log(K.sum(y_true* y_pred,axis=-1))
	return(loss)



def strip_accents(s):
	return ''.join(c for c in unicodedata.normalize('NFD', s)
				  if unicodedata.category(c) != 'Mn')

def clean_str(string):
	"""
	Tokenization/string cleaning for dataset
  
	"""
	string = re.sub(r"\\", "", string)
	string = re.sub(r"\'", "", string)
	string = re.sub(r"\"", "", string)
	return string.strip()

def remove_non_ascii(text):
	text=re.sub(r'\n'," ",text)
	text=re.sub(r'\r'," ",text)
	text=re.sub(r'\\n'," ",text)
	text=re.sub(r'\\r'," ",text)
	return re.sub(r'[^\x00-\x7F]+',' ', text)

def text_cleaner(text):
	#text = text.replace(".", "")
	text = text.replace("[", " ")
	#text = text.replace(",", " ")
	text = text.replace("]", " ")
	text = text.replace("(", " ")
	text = text.replace(")", " ")
	text = text.replace("\"", "")
	#text = text.replace("-", "")
	text = text.replace("=", "")
	#text = text.replace(":", "")
	#text = text.replace("*", "")
	text = text.replace("_", " ")
	text = text.replace(";", " ")
	#text = text.replace("$", " ")
	text = text.replace("?", " ")
	text = text.replace("\’", " ")
	text = text.replace("&nbsp", " ")
	text = text.replace("&#", " ")		
	text = remove_non_ascii(text)
	rules = [
		{r'>\s+': u'>'},  # remove spaces after a tag opens or closes
		{r'\s+': u' '},  # replace consecutive spaces
		{r'\s*<br\s*/?>\s*': u'\n'},  # newline after a <br>
		{r'</(div)\s*>\s*': u'\n'},  # newline after </p> and </div> and <h1/>...
		{r'</(p|h\d)\s*>\s*': u'\n\n'},  # newline after </p> and </div> and <h1/>...
		{r'<head>.*<\s*(/head|body)[^>]*>': u''},  # remove <head> to </head>
		{r'<a\s+href="([^"]+)"[^>]*>.*</a>': r'\1'},  # show links instead of texts
		{r'[ \t]*<[^<]*?/?>': u''},  # remove remaining tags
		{r'^\s+': u''},  # remove spaces at the beginning
		#{ur"[\u4e00-\u9fff]+": u""}
		]
	for rule in rules:
		for (k, v) in rule.items():
			regex = re.compile(k)
			text = regex.sub(v, text)
		text = text.rstrip()
		text = text.strip()
		text = text.lower()
		text = strip_accents(text)
	return text

def main():

	TRAIN_DATA_FILE='/home/CORP/keshav102987/TestML/Toxic_Comments/train.csv'
	TEST_DATA_FILE='/home/CORP/keshav102987/TestML/Toxic_Comments/test.csv'

	df=pd.read_csv(TRAIN_DATA_FILE)
	df1=pd.read_csv(TEST_DATA_FILE)
	#data=df["comment_text"].append(df1["comment_text"],ignore_index=True)


	df["text"]=list(map(lambda x:text_cleaner(x),df["comment_text"]))
	df["text"]=list(map(lambda x:str(x),df["text"]))


	#data=list(map(lambda x:text_cleaner(x),data))
	#data=list(map(lambda x:str(x),data))


	df1["text"]=list(map(lambda x:text_cleaner(x),df1["comment_text"]))
	df1["text"]=list(map(lambda x:str(x),df1["text"]))

	data=list(df["text"].append(df1["text"],ignore_index=True))

	class RocAucEvaluation(Callback):
		def __init__(self, validation_data=(), interval=1):
			super(Callback, self).__init__()
			self.interval = interval
			self.X_val, self.y_val = validation_data
		def on_epoch_end(self, epoch, logs={}):
			if epoch % self.interval == 0:
				y_pred = self.model.predict(self.X_val, verbose=0)
				score = roc_auc_score(self.y_val, y_pred)
				print("\n ROC-AUC - epoch: {:d} - score: {:.6f}".format(epoch+1, score))


	#df["text"].to_csv("uk_vocab.txt",header=None, index=None, sep=str('\n'), mode='a')

			

	#---------------------------------------DEFINTIONS:::::::::::::::::::::::::::::::::::::::::::
	GLOVE_DIR='/home/CORP/udaya105712/Documents/ProductDevelopment/Glove/'

	MAX_NB_WORDS = 200000
	EMBEDDING_DIM = 300
	max_seq_len = 150

	kernel_size=2
	CNN_filters=128
	pool_size=2
	nbatch_size=128

	tokenizer = Tokenizer(num_words =MAX_NB_WORDS)
	tokenizer.fit_on_texts(data)
	word_index = tokenizer.word_index


	embeddings_index = KeyedVectors.load_word2vec_format('/home/CORP/udaya105712/Documents/ProductDevelopment/AMEX_GBT/fastText-0.1.0/uk_vocab.vec', binary=False)


	num_words = max(MAX_NB_WORDS, len(word_index)+1)
	embedding_matrix = np.zeros((num_words, EMBEDDING_DIM))
	for word, i in word_index.items():
		if i >= MAX_NB_WORDS:
			continue
		try:
			embedding_vector = embeddings_index[word]
			if embedding_vector is not None:
				# words not found in embedding index will be all-zeros.
				embedding_matrix[i] = embedding_vector
		except:
			continue

	train, val = train_test_split(df, test_size=0.1)

	# from itertools import izip as zip, count # izip for maximum efficiency
	# from tqdm import tqdm

	# identity_hate = ["nigger","gay","fuck","faggot","fat","jew","fucking","huge","suck","shit","stupid","cunt","ass","mexicans","niggas","bitch","bunksteve","chink","asian","fag","jewish","hate","ancestryfuck","young","licker","hell","spanish","centraliststupid","jews","piece","nigga","sinner","gaylord","homosexual","dick","homo","black","niggers","chinese","american","racist","korean","christian","minorities","japanese","males","christians","killer","giant","hypocrite","lynch","white","dough","friggin","buddha","gandhi","nazi","anti","nl33ers","bush","pussy","mccain","enigmaman","whore","muslim","retarded","old","dirty","homosexuals","dumb","bastard","slut"]
	# toxic = ["fuck","hate","nigger","moron","shit","fucking","pig","stop","gay","wanker","fag","bark","stupid","die","fat","balls","vandalism","aids","make","life","sex","bad","ass","nipple","block","jew","dick","little","suck","bullshit","cunt","faggots","old","hell","bitch","idiot","poop","loser","hitler","noobs","sucks","homo","faggot","boobs","love","big","asshole","fggt","person","ban"]
	# severe_toxic = ["fuck","suck","ass","shit","faggot","fucking","nigger","die","cunt","bitch","sucks","cock","yourselfgo","fucksex","dick","gay","piece","fucker","bastard","asshole","huge","bitches","cocksucker","penis","fat","mothjer","rape","kill","eat","dog","shut","offfuck","pro","anal","hanibal911you","assad","mexicans","stupid","damn","niggas","dickhead","idiot","bunksteve","block","small","criminalwar","pussy","chester","bush","marcolfuck","fack","useless","cocksucking","bot","jewish","ancestryfuck","homeland","securityfuck","mother","whore","moron","veggietales","person","admins","shitfuck","atheist","cunts","fuckin","bleachanhero","lick","big","bitchmattythewhite","cocks","notrhbysouthbanof"]
	# obscene = ["twat","dicks","licks","shit","fuck","ass","personal","fucking","stop","say","bitch","read","want","wrong","block","deal","mean","kurt","dick","blocked","crap","knob","delete","tell","salt","cheese","phuq","cunt","vandalism","understand"]
	# insult = ["twat","neiln","bbb23","dicks","licks","repeat","fool","pathetic","die","stupid","little","stop","bitch","ass","better","idiot","dumb","shit","ignorant","moron","idiots","reason","blocked","asshole","real","black","fuck","pumpkin","pages","cunt","sad","leave"]
	# threat = ["die","kill","block","murder","live","fuckin","di","edie","ban","lifetime","bitch","real","pathetic","forever","death","gonna","dust","harassment","filter","steal","password","blank","rape","hell","destroy","stop","house","dead","beavis","hate","moonshine","shoot","family","cunt","burn","deserve","cut","hello","vagina","dirty","anti","threat","warning","abuse","bash"]
	# normal=["good","thank","great","awesome","discussion","used","read","look","added","welcome","note","free","hi","personal","please" ]

	# combinations=[toxic,severe_toxic,obscene,threat,insult,identity_hate]
	# max_query_len=150

	# queries = []
	# for idx, row in train.iterrows():
	# 	list_response=[row["toxic"],row["severe_toxic"],row["obscene"],row["threat"],row["insult"],row["identity_hate"]]
	# 	index=[i for i, j in zip(count(), list_response) if j == 1]
	# 	if len(index)>0:
	# 		list_combined=list( combinations[i] for i in index )
	# 		flat_list = [item for sublist in list_combined for item in sublist]
	# 		flat_list = list(set(flat_list))
	# 		if len(flat_list)>max_query_len:
	# 			flat_list=flat_list[:max_query_len]
	# 		queries.append(" ".join(flat_list))
	# 	else:
	# 		queries.append(" ".join(normal))


	# queries_val = []
	# for idx, row in val.iterrows():
	# 	list_response=[row["toxic"],row["severe_toxic"],row["obscene"],row["threat"],row["insult"],row["identity_hate"]]
	# 	index=[i for i, j in zip(count(), list_response) if j == 1]
	# 	if len(index)>0:
	# 		list_combined=list( combinations[i] for i in index )
	# 		flat_list = [item for sublist in list_combined for item in sublist]
	# 		flat_list = list(set(flat_list))
	# 		if len(flat_list)>max_query_len:
	# 			flat_list=flat_list[:max_query_len]
	# 		queries_val.append(" ".join(flat_list))
	# 	else:
	# 		queries_val.append(" ".join(normal))


	# max_seq_len =150


	# train_X = tokenizer.texts_to_sequences(train["text"])
	# query_X = tokenizer.texts_to_sequences(list(map(lambda x: str(x),queries)))

	# train_X = np.array(pad_sequences(train_X, maxlen=max_seq_len,padding="post"))
	# query_X = np.array(pad_sequences(query_X, maxlen=max_query_len,padding="post"))

	# val_X = tokenizer.texts_to_sequences(val["text"])
	# queryval_X = tokenizer.texts_to_sequences(list(map(lambda x: str(x),queries_val)))

	# val_X = np.array(pad_sequences(val_X, maxlen=max_seq_len,padding="post"))
	# queryval_X = np.array(pad_sequences(queryval_X, maxlen=max_query_len,padding="post"))


	train_Y=train.as_matrix(columns=["toxic",	"severe_toxic",	"obscene",	"threat"	,"insult",	"identity_hate"])
	val_Y=val.as_matrix(columns=["toxic",	"severe_toxic",	"obscene",	"threat"	,"insult",	"identity_hate"])



	# def generate_queries(test,combinations,normal):
	# 	combinations.append(normal)
	# 	combinations = [item for sublist in combinations for item in sublist]
	# 	queries_list=list(set(combinations))
	# 	queries_test = []
	# 	for i in range(len(test)):
	# 		queries_test.append("".join(queries_list))
	# 	return(queries_test)

	# queries_test=generate_queries(df1["text"],combinations,normal)

	# test_X = tokenizer.texts_to_sequences(df1["text"])
	# queriestest_X = tokenizer.texts_to_sequences(list(map(lambda x : str(x),queries_test)))


	# test_X = np.array(pad_sequences(test_X, maxlen=max_seq_len,padding="post"))
	# queriestest_X = np.array(pad_sequences(queriestest_X, maxlen=max_query_len,padding="post"))



	# np.save("train_X.npy",train_X)
	# np.save("query_X.npy",query_X)
	# np.save("val_X.npy",val_X)
	# np.save("queryval_X.npy",queryval_X)
	# np.save("test_X.npy",test_X)
	# np.save("queriestest_X.npy",queriestest_X)

	# np.save("embedding_matrix.npy",embedding_matrix)
	# df1.to_csv("df1.csv",index=False)

	train_X = np.load("train_X.npy")
	query_X = np.load("query_X.npy")
	val_X = np.load("val_X.npy")
	queryval_X = np.load("queryval_X.npy")
	test_X = np.load("test_X.npy")
	queriestest_X = np.load("queriestest_X.npy")

	embedding_matrix = np.load("embedding_matrix.npy",)
	df1 = pd.read_csv("df1.csv")

	max_query_len=150


	#Word Input layers
	question_input_word=Input(shape=(max_query_len,))
	passage_input_word=Input(shape=(max_seq_len,))

	#word embedding layers #TODO : Add GloVe
	question_wembbeding=Embedding(num_words, EMBEDDING_DIM, weights=[embedding_matrix],input_length=max_query_len,trainable=False)(question_input_word)
	passage_wembbeding=Embedding(num_words, EMBEDDING_DIM, weights=[embedding_matrix],input_length=max_seq_len,trainable=False)(passage_input_word)

	#a.reshape layers
	#question_wreshape1=Reshape((max_query_len, EMBEDDING_DIM))(question_wembbeding)
	#passage_wreshape1=Reshape((max_seq_len, EMBEDDING_DIM))(passage_wembbeding)


	for i in range(2):
		highway_layer = Highway(activation="relu", name='highway_{}'.format(i))
		question_layer = TimeDistributed(highway_layer, name=highway_layer.name + "_qtd")
		question_wreshape1 = question_layer(question_wembbeding)
		passage_layer = TimeDistributed(highway_layer, name=highway_layer.name + "_ptd")
		passage_wreshape1 = passage_layer(passage_wembbeding)


	#Bidirectional LSTM Layer
	question_lstm=Bidirectional(LSTM(150, return_sequences=True), input_shape=(1,max_query_len))(question_wreshape1)
	passage_lstm=Bidirectional(LSTM(150, return_sequences=True), input_shape=(1,max_seq_len))(passage_wreshape1)

	#Attention Layer 
	#Context to Query
	passage_question_similarity=at.MatrixAttention(input_shape=(1,max_seq_len))([passage_lstm,question_lstm])

	y = Conv1D(150, kernel_size = 5, padding = "valid", kernel_initializer = "glorot_uniform")(passage_question_similarity)
	y = MaxPooling1D(pool_size=5)(y)
	y = Conv1D(75, kernel_size = 3, padding = "valid", kernel_initializer = "glorot_uniform")(y)
	y = MaxPooling1D(pool_size=3)(y)
	y = Conv1D(32, kernel_size = 5, padding = "valid", kernel_initializer = "glorot_uniform")(y)
	#avg_pool = GlobalAveragePooling1D()(x)
	max_pool1 = GlobalMaxPooling1D()(y)

	#passage_question_attention=at.Softmax()(passage_question_similarity)
	#passage_question_vectors=at.WeightedSum()([question_lstm,passage_question_attention])

	x = Bidirectional(LSTM(150, return_sequences=True,dropout=0.1,recurrent_dropout=0.1))(passage_wreshape1)
	x = Conv1D(150, kernel_size = 5, padding = "valid", kernel_initializer = "glorot_uniform")(x)
	x = MaxPooling1D(pool_size=5)(x)
	x = Conv1D(75, kernel_size = 3, padding = "valid", kernel_initializer = "glorot_uniform")(x)
	x = MaxPooling1D(pool_size=3)(x)
	x = Conv1D(32, kernel_size = 5, padding = "valid", kernel_initializer = "glorot_uniform")(x)
	#avg_pool = GlobalAveragePooling1D()(x)
	max_pool = GlobalMaxPooling1D()(x)
	x = concatenate([max_pool, max_pool1]) 
	x = Dense(128, activation='relu')(x)
	x = Dropout(0.1)(x)
	preds = Dense(6, activation="sigmoid")(x)
	model = Model([question_input_word,passage_input_word], preds)
	model.compile(loss='binary_crossentropy',optimizer=Adam(lr=1e-3),metrics=['accuracy'])
	model.summary()
	MODEL_PATH="/home/CORP/udaya105712/Documents/ProductDevelopment/AMEX_GBT/pickles1/"
	early_stopping =EarlyStopping(monitor="val_loss", patience=3)

	model_checkpoint = ModelCheckpoint(MODEL_PATH+'model_att2.hdf5',save_best_only=True)
	model.fit([query_X,train_X],train_Y,batch_size=64,epochs=5,validation_data=({"input_1":queryval_X,"input_2":val_X}, val_Y),callbacks=[early_stopping, model_checkpoint],verbose=1)


	model.load_weights(os.path.join(MODEL_PATH,"model_att2.hdf5"))
	y_pred=model.predict([queriestest_X,test_X],batch_size=64,verbose=1)
	sub_pred=pd.DataFrame(y_pred,columns=["toxic",	"severe_toxic",	"obscene",	"threat"	,"insult",	"identity_hate"])
	sub_id=pd.DataFrame(df1["id"],columns=["id"])
	sub_uk=pd.concat([sub_id,sub_pred],axis=1)
	sub_uk.to_csv('submission08.csv', index=False)




if __name__ == '__main__':
	import tensorflow as tf
	config = tf.ConfigProto()
	config.gpu_options.allow_growth = True
	with tf.Session(config=config) as sess:
		sess.run(main())

