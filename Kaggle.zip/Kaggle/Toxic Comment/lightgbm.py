# coding: utf-8
# pylint: disable = invalid-name, C0111
import json
import lightgbm as lgb
import pandas as pd
from sklearn.metrics import mean_squared_error
import numpy as np

import pandas as pd
import numpy as np
import re
import lightgbm as lgb
import warnings
warnings.filterwarnings(action='ignore', category=DeprecationWarning, module='sklearn')
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import cross_val_score


OOF_PATH = "/home/CORP/udaya105712/Documents/ProductDevelopment/AMEX_GBT/oof/"

oof1=np.load(OOF_PATH+"oof_x_model_1.npy")
oof2=np.load(OOF_PATH+"oof_x_model_2.npy")
oof3=np.load(OOF_PATH+"oof_x_model_3.npy")
oof5=np.load(OOF_PATH+"oof_x_model_5.npy")

yoof1=np.load(OOF_PATH+"oof_y_model_1.npy")
yoof2=np.load(OOF_PATH+"oof_y_model_2.npy")
yoof3=np.load(OOF_PATH+"oof_y_model_3.npy")
yoof5=np.load(OOF_PATH+"oof_y_model_5.npy")

X_train = np.vstack((oof1, oof2,oof3,oof5))
y_train = np.vstack((yoof1, yoof2,yoof3,yoof5))

BLEND_PATH = "/home/CORP/udaya105712/Documents/ProductDevelopment/AMEX_GBT/blends/"

b1=pd.read_csv(BLEND_PATH+'cv1.csv')
b2=pd.read_csv(BLEND_PATH+'cv2.csv')
b3=pd.read_csv(BLEND_PATH+'cv3.csv')
b4=pd.read_csv(BLEND_PATH+'cv5.csv')


by = b1.copy()
col = b1.columns

col = col.tolist()
col.remove('id')
for i in col:
    by[i] = (2 * b1[i]  + 2 * b2[i] + b3[i] * 4 + b4[i] * 22 ) /  30




def baseline_model():
    # create model
    model = Sequential()
    model.add(Dense(128, input_dim=6, kernel_initializer='normal', activation='relu'))
    #model.add(Dense(128, kernel_initializer='relu'))
    #model.add(Dense(64, kernel_initializer='relu'))
    #model.add(Dense(32, kernel_initializer='relu'))
    model.add(Dense(6, kernel_initializer='sigmoid'))
    # Compile model
    model.compile(loss='binary_crossentropy',optimizer=Adam(lr=1e-3),metrics=['accuracy'])
    return (model)

model = baseline_model()
model.fit(X_train, y_train, epochs=100, batch_size=10)
























LABELS = by.columns[2:]
stacker = lgb.LGBMClassifier(max_depth=3, metric="auc", n_estimators=125, num_leaves=10, boosting_type="gbdt", learning_rate=0.1, feature_fraction=0.45, colsample_bytree=0.45, bagging_fraction=0.8, bagging_freq=5, reg_lambda=0.2)
# Fit and submit
scores = []
for label,idx in zip(LABELS,range(len(LABELS))):
    print(label)
    score = cross_val_score(stacker, X_train, y_train[:,idx], cv=5, scoring='roc_auc')
    print("AUC:", score)
    scores.append(np.mean(score))
    stacker.fit(X_train, y_train[:,idx])
    by[label] = stacker.predict_proba(by.drop(["id",1]))[:,1]


