import pandas as pd
import numpy as np

m0=pd.read_csv("/home/CORP/udaya105712/Documents/ProductDevelopment/AMEX_GBT/submission_glove_LogisticRegression.csv")
#m1=m1.drop("fold_id",axis=1)
#m1=m1.groupby(["id"],as_index=False).mean()
m0=m0.sort_values(by=['id'])


m1=pd.read_csv("/home/CORP/ankit93726/kaggle/toxic_comments/output/single_model_predictions_03092018/bad_word_logreg_predictions_test_oof.csv")
m1=m1.drop("fold_id",axis=1)
m1=m1.groupby(["id"],as_index=False).mean()
m1=m1.sort_values(by=['id'])

m2=pd.read_csv("/home/CORP/ankit93726/kaggle/toxic_comments/output/single_model_predictions_03092018/char_vdcnn_predictions_test_oof.csv")
m2=m2.drop("fold_id",axis=1)
m2=m2.groupby(["id"],as_index=False).mean()
m2=m2.sort_values(by=['id'])

m3=pd.read_csv("/home/CORP/ankit93726/kaggle/toxic_comments/output/single_model_predictions_03092018/fasttext_dpcnn_predictions_test_oof.csv")
m3=m3.drop("fold_id",axis=1)
m3=m3.groupby(["id"],as_index=False).mean()
m3=m3.sort_values(by=['id'])

m4=pd.read_csv("/home/CORP/ankit93726/kaggle/toxic_comments/output/single_model_predictions_03092018/fasttext_gru_predictions_test_oof.csv")
m4=m4.drop("fold_id",axis=1)
m4=m4.groupby(["id"],as_index=False).mean()
m4=m4.sort_values(by=['id'])

m5=pd.read_csv("/home/CORP/ankit93726/kaggle/toxic_comments/output/single_model_predictions_03092018/fasttext_lstm_predictions_test_oof.csv")
m5=m5.drop("fold_id",axis=1)
m5=m5.groupby(["id"],as_index=False).mean()
m5=m5.sort_values(by=['id'])

m6=pd.read_csv("/home/CORP/ankit93726/kaggle/toxic_comments/output/single_model_predictions_03092018/glove_dpcnn_predictions_test_oof.csv")
m6=m6.drop("fold_id",axis=1)
m6=m6.groupby(["id"],as_index=False).mean()
m6=m6.sort_values(by=['id'])

m7=pd.read_csv("/home/CORP/ankit93726/kaggle/toxic_comments/output/single_model_predictions_03092018/tfidf_logreg_predictions_test_oof.csv")
m7=m7.drop("fold_id",axis=1)
m7=m7.groupby(["id"],as_index=False).mean()
m7=m7.sort_values(by=['id'])



m8=pd.read_csv("/home/CORP/udaya105712/Documents/ProductDevelopment/AMEX_GBT/submissions/submission_uk_model_1_fold_1.csv")
m8=m8.sort_values(by=['id'])

m9=pd.read_csv("/home/CORP/udaya105712/Documents/ProductDevelopment/AMEX_GBT/submissions/submission_uk_model_1_fold_2.csv")
m9=m9.sort_values(by=['id'])

m10=pd.read_csv("/home/CORP/udaya105712/Documents/ProductDevelopment/AMEX_GBT/submissions/submission_uk_model_1_fold_3.csv")
m10=m10.sort_values(by=['id'])

m11=pd.read_csv("/home/CORP/udaya105712/Documents/ProductDevelopment/AMEX_GBT/submissions/submission_uk_model_1_fold_4.csv")
m11=m11.sort_values(by=['id'])

m12=pd.read_csv("/home/CORP/udaya105712/Documents/ProductDevelopment/AMEX_GBT/submissions/submission_uk_model_2_fold_1.csv")
m12=m12.sort_values(by=['id'])

m13=pd.read_csv("/home/CORP/udaya105712/Documents/ProductDevelopment/AMEX_GBT/submissions/submission_uk_model_2_fold_2.csv")
m13=m13.sort_values(by=['id'])

m14=pd.read_csv("/home/CORP/udaya105712/Documents/ProductDevelopment/AMEX_GBT/submissions/submission_uk_model_2_fold_3.csv")
m14=m14.sort_values(by=['id'])

m15=pd.read_csv("/home/CORP/udaya105712/Documents/ProductDevelopment/AMEX_GBT/submissions/submission_uk_model_2_fold_4.csv")
m15=m15.sort_values(by=['id'])

m16=pd.read_csv("/home/CORP/udaya105712/Documents/ProductDevelopment/AMEX_GBT/submissions/submission_uk_model_3_fold_1.csv")
m16=m16.sort_values(by=['id'])

m17=pd.read_csv("/home/CORP/udaya105712/Documents/ProductDevelopment/AMEX_GBT/submissions/submission_uk_model_3_fold_2.csv")
m17=m17.sort_values(by=['id'])

m18=pd.read_csv("/home/CORP/udaya105712/Documents/ProductDevelopment/AMEX_GBT/submissions/submission_uk_model_3_fold_3.csv")
m18=m18.sort_values(by=['id'])

m19=pd.read_csv("/home/CORP/udaya105712/Documents/ProductDevelopment/AMEX_GBT/submissions/submission_uk_model_3_fold_4.csv")
m19=m19.sort_values(by=['id'])

m20=pd.read_csv("/home/CORP/udaya105712/Documents/ProductDevelopment/AMEX_GBT/submissions/submission_uk_model_5_fold_1.csv")
m20=m20.sort_values(by=['id'])

m21=pd.read_csv("/home/CORP/udaya105712/Documents/ProductDevelopment/AMEX_GBT/submissions/submission_uk_model_5_fold_2.csv")
m21=m21.sort_values(by=['id'])

m22=pd.read_csv("/home/CORP/udaya105712/Documents/ProductDevelopment/AMEX_GBT/submissions/submission_uk_model_5_fold_3.csv")
m22=m22.sort_values(by=['id'])

m23=pd.read_csv("/home/CORP/udaya105712/Documents/ProductDevelopment/AMEX_GBT/submissions/submission_uk_model_5_fold_4.csv")
m23=m23.sort_values(by=['id'])


ids=m23['id']

b1 = m8.copy()
col = m8.columns

col = col.tolist()
col.remove('id')
for i in col:
    b1[i] = (m8[i]+ m9[i]  + m10[i] + m11[i]) / 4

b2 = m12.copy()
col = m12.columns

col = col.tolist()
col.remove('id')
for i in col:
    b2[i] = (m12[i]+ m13[i]  + m14[i] + m15[i]) / 4

b3 = m16.copy()
col = m16.columns

col = col.tolist()
col.remove('id')
for i in col:
    b3[i] = (m16[i]+ m17[i]  + m18[i] + m19[i]) / 4


b4 = m20.copy()
col = m20.columns

col = col.tolist()
col.remove('id')
for i in col:
    b4[i] = (m20[i]*4+ m21[i]*2  + m22[i]*4 + m23[i]) / 11




BLEND_PATH = "/home/CORP/udaya105712/Documents/ProductDevelopment/AMEX_GBT/blends/"

b1.to_csv(BLEND_PATH+'cv1.csv', index = False)
b2.to_csv(BLEND_PATH+'cv2.csv', index = False)
b3.to_csv(BLEND_PATH+'cv3.csv', index = False)
b4.to_csv(BLEND_PATH+'cv5.csv', index = False)



by = m20.copy()
col = m20.columns

col = col.tolist()
col.remove('id')
for i in col:
    by[i] = (  7 * b2[i] + b4[i] * 22 ) /  29
  


# by = m20.copy()
# col = m20.columns

# col = col.tolist()
# col.remove('id')
# for i in col:
#     by[i] = (m0[i]*4 +b1[i]  + 2 * b2[i] + b3[i] * 4 + b4[i] * 10 + m1[i]*2 + m2[i] + m3[i]*5 + m4[i] + m5[i] + m6[i] + m7[i]) /  33
    

by.to_csv(BLEND_PATH+'cv_blend1.csv', index = False)

