# coding: utf-8
# pylint: disable = invalid-name, C0111
import json
import lightgbm as lgb
import pandas as pd
from sklearn.metrics import mean_squared_error
import numpy as np

import pandas as pd
import numpy as np
import re
import lightgbm as lgb
import warnings
warnings.filterwarnings(action='ignore', category=DeprecationWarning, module='sklearn')
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import cross_val_score

from gensim.models import KeyedVectors
from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences
from keras.layers import Input, LSTM, Embedding, Dropout
from keras.models import Model
from keras.layers.normalization import BatchNormalization
from keras.layers import Conv1D, MaxPooling1D, Embedding
from keras.callbacks import EarlyStopping, ModelCheckpoint
from keras.utils import to_categorical
from keras.preprocessing import sequence
from keras.models import Sequential
from keras.layers import Dense, Embedding
from keras.layers.core import Flatten,Dense, Activation
from keras.layers import Conv1D, GlobalMaxPooling1D, MaxPooling1D
from sklearn.model_selection import train_test_split
from gensim.models import KeyedVectors
from keras.layers import Input,concatenate,Highway
from keras.layers.wrappers import TimeDistributed,Bidirectional

import os
from keras.layers import Dense,Input,LSTM,Bidirectional,Activation,Conv1D,GRU
from keras.callbacks import Callback
from keras.layers import Dropout,Embedding,GlobalMaxPooling1D, MaxPooling1D, Add, Flatten
from keras.preprocessing import text, sequence
from keras.layers import GlobalAveragePooling1D, GlobalMaxPooling1D, concatenate, SpatialDropout1D
from keras import initializers, regularizers, constraints, optimizers, layers, callbacks
from keras.callbacks import EarlyStopping,ModelCheckpoint
from keras.layers import Input,concatenate,Highway
from keras.layers.wrappers import TimeDistributed,Bidirectional
from keras.models import Model
from keras.optimizers import Adam
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.metrics import roc_auc_score


def main():

    OOF_PATH = "/home/CORP/udaya105712/Documents/ProductDevelopment/AMEX_GBT/oof/"

    oof1=np.load(OOF_PATH+"oof_x_model_1.npy")
    oof2=np.load(OOF_PATH+"oof_x_model_2.npy")
    oof3=np.load(OOF_PATH+"oof_x_model_3.npy")
    oof5=np.load(OOF_PATH+"oof_x_model_5.npy")

    yoof1=np.load(OOF_PATH+"oof_y_model_1.npy")
    yoof2=np.load(OOF_PATH+"oof_y_model_2.npy")
    yoof3=np.load(OOF_PATH+"oof_y_model_3.npy")
    yoof5=np.load(OOF_PATH+"oof_y_model_5.npy")

    X_train = np.vstack((oof1, oof2,oof3,oof5))
    y_train = np.vstack((yoof1, yoof2,yoof3,yoof5))

    BLEND_PATH = "/home/CORP/udaya105712/Documents/ProductDevelopment/AMEX_GBT/blends/"

    b1=pd.read_csv(BLEND_PATH+'cv1.csv')
    b2=pd.read_csv(BLEND_PATH+'cv2.csv')
    b3=pd.read_csv(BLEND_PATH+'cv3.csv')
    b4=pd.read_csv(BLEND_PATH+'cv5.csv')


    by = b1.copy()
    col = b1.columns

    col = col.tolist()
    col.remove('id')
    for i in col:

        by[i] = (2 * b1[i]  + 2 * b2[i] + b3[i] * 4 + b4[i] * 22 ) /  30




    def baseline_model():
        # create model
        model = Sequential()
        model.add(Dense(128, input_dim=6, kernel_initializer='normal', activation='relu'))
        #model.add(Dense(128, kernel_initializer='relu'))
        model.add(Dense(64, activation='relu'))
        #model.add(Dense(32, kernel_initializer='relu'))
        model.add(Dense(6, activation='sigmoid'))
        # Compile model
        model.compile(loss='binary_crossentropy',optimizer=Adam(lr=1e-3),metrics=['accuracy'])
        return (model)

    model = baseline_model()
    model.fit(X_train, y_train, epochs=100, batch_size=128)
    predictions = model.predict(by.drop("id",1),verbose=1)
    submission = pd.DataFrame(predictions,columns=["toxic",  "severe_toxic", "obscene",  "threat"    ,"insult",  "identity_hate"])
    submission["id"]=by["id"]
    submission.to_csv(BLEND_PATH+"MLP_1.csv",index=False)

if __name__ == '__main__':
    import tensorflow as tf
    os.environ['CUDA_VISIBLE_DEVICES']="-1"
    #config = tf.ConfigProto(device_count={"GPU":0})
    #config.gpu_options.allow_growth = True
    with tf.Session() as sess:
        with tf.device('/cpu:0'):
            sess.run(main())

