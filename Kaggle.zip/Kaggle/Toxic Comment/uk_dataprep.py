# -*- coding: utf-8 -*-
"""
Created on Wed May 31 12:11:38 2017

@author: udaya105712
"""

#Preprocess BiDAF
from __future__ import unicode_literals

import sys
import random
import codecs
import datetime
import logging
import time
import shutil
import unicodedata
import nltk
import os
import re
import csv
import codecs
import numpy as np
import pandas as pd
import keras
import random
import sys
import re
import six.moves.cPickle


from gensim.models import KeyedVectors
from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences
from keras.layers import Input, LSTM, Embedding, Dropout
from keras.models import Model
from keras.layers.normalization import BatchNormalization
from keras.layers import Conv1D, MaxPooling1D, Embedding
from keras.callbacks import EarlyStopping, ModelCheckpoint
from keras.utils import to_categorical
from keras.preprocessing import sequence
from keras.models import Sequential
from keras.layers import Dense, Embedding
from keras.layers.core import Flatten,Dense, Activation
from keras.layers import Conv1D, GlobalMaxPooling1D, MaxPooling1D
from sklearn.model_selection import train_test_split
from gensim.models import KeyedVectors
from keras.layers import Input,concatenate,Highway
from keras.layers.wrappers import TimeDistributed,Bidirectional

import os
from keras.layers import Dense,Input,LSTM,Bidirectional,Activation,Conv1D,GRU
from keras.callbacks import Callback
from keras.layers import Dropout,Embedding,GlobalMaxPooling1D, MaxPooling1D, Add, Flatten
from keras.preprocessing import text, sequence
from keras.layers import GlobalAveragePooling1D, GlobalMaxPooling1D, concatenate, SpatialDropout1D
from keras import initializers, regularizers, constraints, optimizers, layers, callbacks
from keras.callbacks import EarlyStopping,ModelCheckpoint
from keras.layers import Input,concatenate,Highway
from keras.layers.wrappers import TimeDistributed,Bidirectional
from keras.models import Model
from keras.optimizers import Adam
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.metrics import roc_auc_score



reload(sys)
sys.setdefaultencoding('utf-8')
random.seed(111)

#def main():
def cust_loss(y_true,y_pred):
	loss=-K.log(K.sum(y_true* y_pred,axis=-1))
	return(loss)



def strip_accents(s):
	return ''.join(c for c in unicodedata.normalize('NFD', s)
				  if unicodedata.category(c) != 'Mn')

def clean_str(string):
	"""
	Tokenization/string cleaning for dataset
  
	"""
	string = re.sub(r"\\", "", string)
	string = re.sub(r"\'", "", string)
	string = re.sub(r"\"", "", string)
	return string.strip()

def remove_non_ascii(text):
	text=re.sub(r'\n'," ",text)
	text=re.sub(r'\r'," ",text)
	text=re.sub(r'\\n'," ",text)
	text=re.sub(r'\\r'," ",text)
	return re.sub(r'[^\x00-\x7F]+',' ', text)

def text_cleaner(text):
	#text = text.replace(".", "")
	text = text.replace("[", " ")
	#text = text.replace(",", " ")
	text = text.replace("]", " ")
	text = text.replace("(", " ")
	text = text.replace(")", " ")
	text = text.replace("\"", "")
	#text = text.replace("-", "")
	text = text.replace("=", "")
	#text = text.replace(":", "")
	#text = text.replace("*", "")
	text = text.replace("_", " ")
	text = text.replace(";", " ")
	#text = text.replace("$", " ")
	text = text.replace("?", " ")
	text = text.replace("\’", " ")
	#text = text.replace("&nbsp", " ")
	#text = text.replace("&#", " ")		
	text = remove_non_ascii(text)
	rules = [
		{r'>\s+': u'>'},  # remove spaces after a tag opens or closes
		{r'\s+': u' '},  # replace consecutive spaces
		{r'\s*<br\s*/?>\s*': u'\n'},  # newline after a <br>
		{r'</(div)\s*>\s*': u'\n'},  # newline after </p> and </div> and <h1/>...
		{r'</(p|h\d)\s*>\s*': u'\n\n'},  # newline after </p> and </div> and <h1/>...
		{r'<head>.*<\s*(/head|body)[^>]*>': u''},  # remove <head> to </head>
		{r'<a\s+href="([^"]+)"[^>]*>.*</a>': r'\1'},  # show links instead of texts
		{r'[ \t]*<[^<]*?/?>': u''},  # remove remaining tags
		{r'^\s+': u''},  # remove spaces at the beginning
		#{ur"[\u4e00-\u9fff]+": u""}
		]
	for rule in rules:
		for (k, v) in rule.items():
			regex = re.compile(k)
			text = regex.sub(v, text)
		text = text.rstrip()
		text = text.strip()
		text = text.lower()
		text = strip_accents(text)
	return text

class RocAucEvaluation(Callback):
	def __init__(self, validation_data=(), interval=1):
		super(Callback, self).__init__()
		self.interval = interval
		self.X_val, self.y_val = validation_data
	def on_epoch_end(self, epoch, logs={}):
		if epoch % self.interval == 0:
			y_pred = self.model.predict(self.X_val, verbose=0)
			score = roc_auc_score(self.y_val, y_pred)
			print("\n ROC-AUC - epoch: {:d} - score: {:.6f}".format(epoch+1, score))

def main():
	TRAIN_DATA_FILE='/home/CORP/keshav102987/TestML/Toxic_Comments/train.csv'
	TEST_DATA_FILE='/home/CORP/keshav102987/TestML/Toxic_Comments/test.csv'

	df=pd.read_csv(TRAIN_DATA_FILE)
	df1=pd.read_csv(TEST_DATA_FILE)
	data=df["comment_text"].append(df1["comment_text"],ignore_index=True)


	df["text"]=list(map(lambda x:text_cleaner(x),df["comment_text"]))
	df["text"]=list(map(lambda x:str(x),df["text"]))


	data=list(map(lambda x:text_cleaner(x),data))
	data=list(map(lambda x:str(x),data))


	df1["text"]=list(map(lambda x:text_cleaner(x),df1["comment_text"]))
	df1["text"]=list(map(lambda x:str(x),df1["text"]))


	#df["text"].to_csv("uk_vocab.txt",header=None, index=None, sep=str('\n'), mode='a')

			

	#---------------------------------------DEFINTIONS:::::::::::::::::::::::::::::::::::::::::::
	GLOVE_DIR='/home/CORP/udaya105712/Documents/ProductDevelopment/Glove/'

	MAX_NB_WORDS = 200000
	EMBEDDING_DIM = 300
	max_seq_len = 100

	kernel_size=2
	CNN_filters=128
	pool_size=2
	nbatch_size=128






	tokenizer = Tokenizer(num_words =MAX_NB_WORDS)
	tokenizer.fit_on_texts(data)
	word_index = tokenizer.word_index


	# #------------------------- CREATING EMBEDDING MATRIX________________

	# embeddings_index = {}
	# f = open(os.path.join(GLOVE_DIR, 'glove.6B.100d.txt'),encoding='utf-8')
	# for line in tqdm(f):
	# 	values = line.split()
	# 	word = values[0]
	# 	coefs = np.asarray(values[1:], dtype='float32')
	# 	embeddings_index[word] = coefs
	# f.close()
	#num_words=91889

	embeddings_index = KeyedVectors.load_word2vec_format('/home/CORP/udaya105712/Documents/ProductDevelopment/AMEX_GBT/fastText-0.1.0/uk_vocab.vec', binary=False)


	num_words = max(MAX_NB_WORDS, len(word_index)+1)
	embedding_matrix = np.zeros((num_words, EMBEDDING_DIM))
	for word, i in word_index.items():
		if i >= MAX_NB_WORDS:
			continue
		try:
			embedding_vector = embeddings_index[word]
			if embedding_vector is not None:
				# words not found in embedding index will be all-zeros.
				embedding_matrix[i] = embedding_vector
		except:
			continue


	np.save("/home/CORP/udaya105712/Documents/ProductDevelopment/AMEX_GBT/embedding_matrix_"+str(num_words)+"_"+str(EMBEDDING_DIM)+".npy",embedding_matrix)

	X = tokenizer.texts_to_sequences(df["text"])
	X = np.array(pad_sequences(X, maxlen=max_seq_len,padding="post"))

	Y=df.as_matrix(columns=["toxic",   "severe_toxic", "obscene",  "threat"    ,"insult",  "identity_hate"])

	test_X = tokenizer.texts_to_sequences(df1["text"])
	test_X = np.array(pad_sequences(test_X, maxlen=max_seq_len,padding="post"))

	np.save("/home/CORP/udaya105712/Documents/ProductDevelopment/AMEX_GBT/X.npy",X)
	np.save("/home/CORP/udaya105712/Documents/ProductDevelopment/AMEX_GBT/Y.npy",Y)
	np.save("/home/CORP/udaya105712/Documents/ProductDevelopment/AMEX_GBT/test_X.npy",test_X)
	df1.to_csv("/home/CORP/udaya105712/Documents/ProductDevelopment/AMEX_GBT/on_preds.csv",index=False)


if __name__ == '__main__':
	import tensorflow as tf
	config = tf.ConfigProto()
	config.gpu_options.allow_growth = True
	with tf.Session(config=config) as sess:
		sess.run(main())
