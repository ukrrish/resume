class NeuralNet(nn.Module):
    def __init__(self):
        super(NeuralNet, self).__init__()
        hidden_size = 40
        self.embedding = nn.Embedding(max_features, embed_size)
        #self.embedding.weight = nn.Parameter(torch.tensor(embedding_matrix, dtype=torch.float32))
        #self.embedding.weight.requires_grad = False
        #
        self.embedding_dropout = nn.Dropout2d(0.1)
        self.lstm = nn.LSTM(embed_size, hidden_size, bidirectional=True, batch_first=True)
        self.gru = nn.GRU(hidden_size * 2, hidden_size, bidirectional=True, batch_first=True)
        #
        # self.lstm_attention = Attention(hidden_size * 2, maxlen)
        # self.gru_attention = Attention(hidden_size * 2, maxlen)
        # #
        self.linear = nn.Linear(320, 16)
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(0.1)
        self.out = nn.Linear(16, 1)
    #
    def forward(self, x):
        h_embedding = self.embedding(x)
        h_embedding = torch.squeeze(
            self.embedding_dropout(torch.unsqueeze(h_embedding, 0)))
        #
        h_lstm, _ = self.lstm(h_embedding)
        h_gru, _ = self.gru(h_lstm)
        #
        # h_lstm_atten = self.lstm_attention(h_lstm)
        # h_gru_atten = self.gru_attention(h_gru)
        # #
        # global average pooling
        avg_pool = torch.mean(h_gru, 1)
        # global max pooling
        max_pool, _ = torch.max(h_gru, 1)
        #
        conc = torch.cat(( avg_pool, max_pool), 1)
        conc = self.relu(self.linear(conc))
        conc = self.dropout(conc)
        out = self.out(conc)
        #
        return out

# pytorch imports
import torch
import torch.nn as nn
import torch.utils.data



class BasicCNN1D(nn.Module): 
    def __init__(self):
        super(BasicCNN1D, self).__init__()
        self.model_name = 'CNNText'
        self.embedding_dim=70
        self.content_dim=512
        self.kernel_size=3
        self.embedding = nn.Embedding(max_features, embed_size)
        #self.embedding.weight = nn.Parameter(torch.tensor(embedding_matrix, dtype=torch.float32))
        #self.embedding.weight.requires_grad = False
        self.cnn1d_only = nn.Sequential(
            nn.Conv1d(in_channels = self.embedding_dim,
                      out_channels = self.content_dim, #256
                      kernel_size = self.kernel_size), #3
            nn.ReLU()
            )
        self.cnn1d_custmaxpool = nn.Sequential(
            nn.Conv1d(in_channels = 512,
                      out_channels = self.content_dim, #256
                      kernel_size = self.kernel_size), #3
            nn.ReLU(),
            nn.MaxPool1d(kernel_size = 5)
            )
        self.linear = nn.Linear(59, 16)
        self.relu = nn.ReLU()
        self.out = nn.Linear(16, 1)
    def forward(self,  x):
        h_embedding = self.embedding(x)
        h_cnn1d_1 = self.cnn1d_custmaxpool(h_embedding)
        h_cnn1d_2 = self.cnn1d_custmaxpool(h_cnn1d_1)
        max_pool,_ = torch.max(h_cnn1d_2, 1)
        conc = self.relu(self.linear(max_pool))
        out = self.out(conc)
        return out


h_embedding = model.embedding(x_batch)
h_cnn1d_1 = model.cnn1d_only(h_embedding)
h_cnn1d_2 = model.cnn1d_custmaxpool(h_cnn1d_1) 
max_pool,_ = torch.max(h_cnn1d_2,1) 
conc = model.relu(model.linear(max_pool)) 
out = model.out(conc)