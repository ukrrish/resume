[‎3/‎22/‎2018 8:41 PM] Vikas Kumar (AM): 
    def load_mask(self, image_id):
        """ 
        Returns:
            masks: A binary array of shape [height, width, instance count] with
                a binary mask per instance.
            class_ids: a 1D array of class IDs of the instance masks.
        """
        info = self.image_info[image_id]
        mask_dir= info['mask_dir'] 
        mask_names = os.listdir(mask_dir)
        mask_paths = [mask_dir + mask_name for mask_name in mask_names]
        
        count = len(mask_paths)
        
        masks = [imageio.imread(path) for path in mask_paths]
        mask = np.stack(masks, axis=-1)
#        mask = mask.astype(bool)
        mask = np.where(mask>128, 1, 0) 



def masks_to_multi_mask(masks):
    '''inputs:[h,w,c] c = no of channels
        outputs= all channels in one frame ( different num of different channels)
    '''
    multi_mask=np.zeros((masks.shape[0],masks.shape[1]),np.int32) 
    for i in range(masks.shape[-1]):
        mask_=masks[:,:,i]
        #multi_masks=np.maximum(multi_masks, mask_)
        #mask = cv2.imread(mask_file,cv2.IMREAD_GRAYSCALE)
        #multi_mask[np.where(mask>128)] = i+1
        multi_mask[np.where(mask_==1)] = i+1
    return multi_mask 


